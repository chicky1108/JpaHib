package com.cg.project.client;

import java.util.Scanner;

import com.cg.project.beans.Author;
import com.cg.project.exception.AuthorNotFoundException;
import com.cg.project.exception.BookNotFoundException;
import com.cg.project.services.AuthorServices;
import com.cg.project.services.AuthorServicesImpl;
import com.cg.project.services.BookServicesImpl;

public class MainClass {
	static Scanner sc = new Scanner(System.in);
	static BookServicesImpl services = new BookServicesImpl();
	static AuthorServices service = new AuthorServicesImpl();
public static void main(String args[]) throws BookNotFoundException, AuthorNotFoundException {
mainScreen();
int choiceOfClient = sc.nextInt();

choiceMenu(choiceOfClient);
}

	private static void choiceMenu(int choiceOfClient) throws  BookNotFoundException,AuthorNotFoundException {
		switch(choiceOfClient)
		{
		case 1:
			System.out.println("Enter Author Name to register-");
			String authorName=sc.next();
			System.out.println("Enter Author Id-");
			int authorId = sc.nextInt();
			service.acceptAuthorDetails(authorId, authorName);
		
			//System.out.println("Enter the ISBN");
			//int ISBN=sc.nextInt();
			System.out.println("Enter title");
			String title=sc.next();
			System.out.println("Enter price");
			int price=sc.nextInt();
			System.out.println("Enter Author Id");
			int authorId1  = sc.nextInt();
			services.acceptBookDetails(title,price,authorId1);
				break;
		
		case 2:
			try{System.out.println("Enter the ISBN");
			int ISBN1=sc.nextInt();
			System.out.println(services.getBookDetails(ISBN1));
			}
			catch(BookNotFoundException e) {e.printStackTrace();}
			break;
		case 3:
			System.out.println("All books in Database are:-");
			System.out.println(services.getAllBookDetails());
			break;

		/*case 4:
			System.out.println("Enter the lastName:");
			String lastName1=sc.next();
			System.out.println("Enter the author id");
			int authorId2=sc.nextInt();
			services.update(lastName1, authorId2);
			break;

		case 5:System.out.println("Enter the author id which is to be deleted");
		int authorId3=sc.nextInt();
		services.deleteAuthor(authorId3);
			
			break;*/

		case 4:
			System.exit(0);

		default:
			System.out.println("Invalid choice!!. Please try again..");
		}
		sc.nextLine();
		main(null);}
	public static void mainScreen() {
		System.out.println("\n\n_______________________________________Welcome to Author Information Page_______________________________________");
		System.out.println("Please Enter any one of the choices:-");
		System.out.println("1. Create an entry");
		System.out.println("2. Get a book Details");
		System.out.println("3. Get all book Details");
		System.out.println("4. Exit\n");

	}

}